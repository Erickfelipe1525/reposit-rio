const CACHE_NAME = 'lifego-v1.0.0';
const urlsToCache = [
  './',
  './index.html',
  './manifest.json',
  
  // Imagens principais
  'logolifego192.png',
  'logolifego512.png',
  
  // Ícones de navegação
  'casa.png',
  'procurar.png',
  'upload.png',
  'chat.png',
  'perfil.png',
  
  // Ícones de ações
  'like.png',
  'comentarios.png',
  'compartilhar.png',
  'download.png',
  
  // Ícones de funcionalidades
  'ia.png',
  'notificações.png',
  'configuracoes.png',
  'modo-escuro.png',
  'bloqueio.png',
  
  // Ícones utilitários
  'voltar.png',
  'modelo.png',
  'denuncia.png',
  'editar.png',
  'filtro.png',
  'seguidores.png'
];

self.addEventListener('install', event => {
  console.log('🟢 Service Worker Lifego instalando...');
  
  // Fazer install mais rápido - não travar a instalação
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('📦 Cache aberto, adicionando arquivos...');
        // Usar addAll mas não travar se algum arquivo falhar
        return cache.addAll(urlsToCache).catch(error => {
          console.warn('⚠️ Alguns arquivos não foram cacheados:', error);
        });
      })
      .then(() => {
        console.log('✅ Recursos principais em cache');
        return self.skipWaiting(); // Ativar imediatamente
      })
  );
});

self.addEventListener('activate', event => {
  console.log('🟠 Service Worker Lifego ativado');
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          // Remove caches antigos de versões diferentes
          if (cacheName !== CACHE_NAME && cacheName.startsWith('lifego')) {
            console.log('🗑️ Removendo cache antigo:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('🎯 Service Worker pronto para controlar clientes');
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', event => {
  // Só processar requisições GET
  if (event.request.method !== 'GET') return;
  
  // Ignorar requisições para APIs externas se quiser
  if (event.request.url.includes('/api/')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        // Se tem no cache, retorna mesmo que esteja offline
        if (cachedResponse) {
          console.log('📁 Servindo do cache:', event.request.url);
          return cachedResponse;
        }

        // Se não tem no cache, busca na rede
        return fetch(event.request)
          .then(networkResponse => {
            // Verifica se a resposta é válida
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }

            // Clona a resposta para cache e uso
            const responseToCache = networkResponse.clone();

            // Adiciona ao cache para próximas requisições
            caches.open(CACHE_NAME)
              .then(cache => {
                // Cache apenas de recursos estáticos
                if (event.request.url.match(/\.(png|jpg|jpeg|gif|svg|css|js|html|json|ico)$/)) {
                  cache.put(event.request, responseToCache);
                  console.log('💾 Novo recurso em cache:', event.request.url);
                }
              })
              .catch(error => {
                console.warn('⚠️ Erro ao adicionar ao cache:', error);
              });

            return networkResponse;
          })
          .catch(error => {
            console.error('🌐 Erro na requisição:', error);
            
            // Fallback para páginas - sempre retorna a app shell
            if (event.request.destination === 'document' || 
                event.request.headers.get('accept').includes('text/html')) {
              return caches.match('./index.html');
            }
            
            // Pode adicionar mais fallbacks aqui se quiser
            // return caches.match('./images/fallback.png');
          });
      })
  );
});

// Ouvinte para mensagens da aplicação (opcional)
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

// Ouvinte para sincronização em background (opcional - para futuras features)
self.addEventListener('sync', event => {
  if (event.tag === 'background-sync') {
    console.log('🔄 Sincronização em background');
    // Aqui você pode implementar sync de dados quando online
  }
});